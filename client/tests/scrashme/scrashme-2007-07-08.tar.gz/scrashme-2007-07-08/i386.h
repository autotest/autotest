#include "syscalls-i386.h"

#define KERNEL_ADDR	0xc0100220

