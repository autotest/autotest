extern void setup_fds(void);
extern void close_fds(void);
extern int get_random_fd();

