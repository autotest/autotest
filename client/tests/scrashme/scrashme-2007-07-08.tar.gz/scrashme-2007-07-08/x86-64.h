#include "syscalls-x86_64.h"

#define KERNEL_ADDR	0xffffffff80100f18

