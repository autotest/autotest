#!/bin/sh
#
# Test recovery or an orphaned character-special device
#

#THINGS_TO_KILL sleep

WHERE=$1
ZERO=$WHERE/zero

# Put a /dev/zero on target device
rm -f $ZERO
mknod $ZERO c 1 5

# Open it
( sleep 1000 & ) < $ZERO

rm $ZERO

