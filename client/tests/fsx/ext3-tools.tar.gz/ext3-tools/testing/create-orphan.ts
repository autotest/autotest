#!/bin/sh
#
# create-orphan.ts
#
# An one-shot which crashes the fs while files are unlinked but open
#

#THINGS_TO_KILL sleep

ORPHAN=orphan_file

cd $1
for i in 0 1 2 3 4 5 6 7 8 9
do
	dd if=/dev/zero of=$ORPHAN.$i bs=100 count=100
	( sleep 100 < $ORPHAN.$i ) &
	rm $ORPHAN.$i
done
sleep 1000
