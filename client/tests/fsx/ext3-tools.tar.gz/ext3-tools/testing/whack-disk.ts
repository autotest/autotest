#!/bin/sh
#
# create-orphan.ts
#
# An one-shot which crashes the fs while files are unlinked but open
#

#THINGS_TO_KILL whack-disk sleep bonnie++ dbench iozone test.sh test2.sh cr ra radc

EXT3_CVS=$(cd .. ; /bin/pwd)
cd $1
$EXT3_CVS/testing/whack-disk &
sleep 1000
