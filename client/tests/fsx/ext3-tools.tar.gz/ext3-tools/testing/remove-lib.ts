#!/bin/sh
#
# ts-copy-kenrel
#

#THINGS_TO_KILL rm

cd $1
rm -rf ./lib-1 &
rm -rf ./lib-2

