#!/bin/sh
#
# ts-iozone
#

#THINGS_TO_KILL iozone

cd $1/iozone/src/current
./iozone -s 10000 -l2 -u3 -BDGEaM
