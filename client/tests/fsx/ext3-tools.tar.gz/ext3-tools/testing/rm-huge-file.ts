#!/bin/sh
#
# rm-huge-file.ts
#

#THINGS_TO_KILL rm

cd $1
rm huge-file		# Tricky to hit

