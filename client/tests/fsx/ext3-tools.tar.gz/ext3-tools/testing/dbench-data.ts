#!/bin/sh
#
# dbench-data.ts: Run dbench, and also create and
# free lots of metadata so that revokes get used.
#

#THINGS_TO_KILL dbench create-delete-data

HERE=$(/bin/pwd)
WHERE=$1

rm -rf $1/cdd
mkdir $1/cdd
../tools/create-delete-data $1/cdd &
cd $1/dbench
./dbench 6
