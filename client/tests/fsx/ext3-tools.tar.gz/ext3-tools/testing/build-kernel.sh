#!/bin/sh
#

. $(dirname $0)/functions

usage()
{
	echo "Usage: build-kernel.sh /path/to/kernel/tree"
	exit 1
}

if [ $# -ne 1 ]
then
	usage
fi

while true
do
	doit rm -rf kernel
	doit cp -a $1 kernel
	cd kernel
	doit make oldconfig
	doit make dep
	doit make -j3 bzImage
	cd ..
	doit rm -rf kernel
done
