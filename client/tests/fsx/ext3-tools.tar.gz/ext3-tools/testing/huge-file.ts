#!/bin/sh
#
# huge-file.ts
#

#THINGS_TO_KILL dd

cd $1
dd if=/dev/zero of=huge-file bs=1000000 count=500	# 500 meg

