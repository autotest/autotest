#!/bin/sh
#
# ts-iozone
#

#THINGS_TO_KILL bonnie++

cd $1/bonnie++
rm -rf Bonnie*
./bonnie++
