#!/bin/sh
#
# ts-iozone
#

#THINGS_TO_KILL mmap002

cd $1/memtest
./mmap002
