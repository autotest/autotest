#!/bin/sh
#
# ts-dbench: Run dbench
#

#THINGS_TO_KILL dbench

cd $1/dbench
./dbench 12
