#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <fcntl.h>
#include <sys/stat.h>
#include <sys/types.h>

static void doit(char *name)
{
	static char stuff[4096];
	int fd;

	fd = creat(name, 0666);
	if (fd < 0) {
		perror(name);
		exit(1);
	}
	write(fd, stuff, sizeof(stuff));
	close(fd);
}

int main(int argc, char *argv[])
{
	int i, j, k, l, m;
	char buf[100];
	int nr = 10;

	if (argc > 1)
		nr = atoi(argv[1]);
	printf("creating %d files\n",
		nr * nr * nr * nr * nr);

	for (i = 0; i < nr; i++) {
		sprintf(buf, "%02d", i);
		mkdir(buf, 0777);
		for (j = 0; j < nr; j++) {
			sprintf(buf, "%02d/%02d", i, j);
			mkdir(buf, 0777);
			printf("%s\n", buf);
			for (k = 0; k < nr; k++) {
				sprintf(buf, "%02d/%02d/%02d", i, j, k);
				mkdir(buf, 0777);
				for (l = 0; l < nr; l++) {
					sprintf(buf, "%02d/%02d/%02d/%02d", i, j, k, l);
					mkdir(buf, 0777);
					for (m = 0; m < nr; m++) {
						sprintf(buf, "%02d/%02d/%02d/%02d/%02d", i, j, k, l, m);
						doit(buf);
					}
				}
			}
		}
	}
	exit(0);
}
