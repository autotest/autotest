#ifndef __NR_sys_remap_file_pages
#if defined (__i386__)
#define __NR_sys_remap_file_pages	257
#elif defined(__powerpc__)
#define __NR_sys_remap_file_pages	239
#endif
#endif

#if defined(__i386__)
_syscall5(	int, sys_remap_file_pages,
		void *, start,
		unsigned long, size,
		unsigned long, prot,
		unsigned long, pgoff,
		unsigned long, flags)

#elif defined(__powerpc__)

#define sys_remap_file_pages(start, size, prot, pgoff, flags) \
	syscall(__NR_sys_remap_file_pages, start, size, prot, pgoff, flags)

#endif

