#!/usr/bin/env bash
grep "^#define __NR_" $1 | \
    sed "s/#define __NR_//g" | \
    awk '{ printf "    { %-28s, %3d,   0 },\n", "\"" $1 "\"", $2 }'

