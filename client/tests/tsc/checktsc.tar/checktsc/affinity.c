#include <errno.h>
#include <sched.h>
#include <unistd.h>
#include <sys/types.h>
#include <asm/unistd.h>


_syscall3(int, sched_setaffinity, pid_t, pid, size_t, len,
		__const cpu_set_t *, mask)
_syscall3(int, sched_getaffinity, pid_t, pid, size_t, len,
		cpu_set_t *, mask)
