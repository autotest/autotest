#include "version.h"

const char libhugetlbfs_version[] = "VERSION: "VERSION;
