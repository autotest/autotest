from distutils.core import setup
setup(name='kvmtest',
      version='0.1',
      py_modules=['kvmtest'],
      scripts=['kvm-test-record', 'kvm-test-replay'],
      )
