import sys

text = open(sys.argv[1], "r").read()

lines = text.split('\n')

new_lines = lines[0:2]

for line in lines[2:]:
    parts = map(lambda x: x.strip(), line.split(','))

    if parts[0] == 'barrier':
        timeout, tolerance = parts[2].split(':', 1)
        parts[2] = '%d:%s' % (0, tolerance)
    
    new_lines.append(', '.join(parts))

f = open(sys.argv[1], "w")
f.write('\n'.join(new_lines))
f.close()
