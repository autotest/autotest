#! /bin/sh
#
# Test that the file is open for read acces when the applications specify
# the value of O_RDONLY.
#
# This is tested implicitly via assertion 1.

echo "Tested implicitly via assertion 1."
exit 0
