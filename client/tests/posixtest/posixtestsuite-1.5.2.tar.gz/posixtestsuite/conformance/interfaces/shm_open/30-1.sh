#! /bin/sh
#
# Test that shm_open() returns a  non-negative integer representing the
# lowest numbered unused file descriptor upon successful completion.
#
# This is tested implicitly via assertion 8.

echo "Tested implicitly via assertion 8."
exit 0

