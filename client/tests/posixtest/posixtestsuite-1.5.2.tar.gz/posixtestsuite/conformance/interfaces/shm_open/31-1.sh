#! /bin/sh
#
# Test that shm_open() return -1 upon unsuccessful completion.
#
# This is tested implicitly via assertions 32 to 42.

echo "Tested implicitly via assertions 32 to 42."
exit 0
