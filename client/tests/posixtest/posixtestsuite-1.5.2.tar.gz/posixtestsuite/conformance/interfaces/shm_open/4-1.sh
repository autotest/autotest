#! /bin/sh
#
# Test that the name argument conforms to the construction rules for a
# pathname.
#
# This is tested implicitly via assertion 39.

echo "Tested implicitly via assertion 39."
exit 0
