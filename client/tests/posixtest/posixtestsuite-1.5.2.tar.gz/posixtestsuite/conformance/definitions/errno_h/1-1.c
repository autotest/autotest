/*
 * This test tests if error.h is exist and useble
 *author:ysun@lnxw.com
 */

#include <errno.h>
