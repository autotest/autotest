#include <mqueue.h>
#include "posixtest.h"
#include <stdio.h>
/* 
   Test for the existance and valid prototype
   of the mq_notify function as specified on
   line 9686 of the Base Definitions document
*/

int main()
{
	fprintf(stderr, "Test not implemented!\n");
	return PTS_UNTESTED;
}
