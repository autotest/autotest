/*
  Test for the existance and valid prototype
  of the mq_timedreceive function as specified on
  line 9692 of the Base Definitions document
*/

#include <mqueue.h>
#include "posixtest.h"
#include <stdio.h>

int main()
{
        fprintf(stderr, "Test not implemented!\n");
        return PTS_UNTESTED;
}
