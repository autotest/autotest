  /*
  Test that the ILL_ILLTRP macro is defined.
  */

#include <signal.h>

#ifndef ILL_ILLTRP
#error ILL_ILLTRP not defined
#endif
