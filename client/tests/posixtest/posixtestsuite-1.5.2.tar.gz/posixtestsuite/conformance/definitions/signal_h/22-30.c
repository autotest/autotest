  /*
  Test that the POLL_IN macro is defined.
  */

#include <signal.h>

#ifndef POLL_IN
#error POLL_IN not defined
#endif
