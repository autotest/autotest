  /*
  Test that the SI_QUEUE macro is defined.
  */

#include <signal.h>

#ifndef SI_QUEUE
#error SI_QUEUE not defined
#endif
