  /*
  Test the definition of ucontext_t.
  */

#include <ucontext.h>

ucontext_t dummy;
