  /*
  Test that the SI_MESGQ macro is defined.
  */

#include <signal.h>

#ifndef SI_MESGQ
#error SI_MESGQ not defined
#endif
