  /*
  Test the definition of pid_t.
  */

#include <sys/types.h>

pid_t dummy;
