  /*
  Test the definition of sig_atomic_t.
  */

#include <signal.h>

sig_atomic_t dummy;
