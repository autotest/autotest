#!/bin/sh

wantdir()
{
	if [ ! -d $1 ]
	then
		echo $1: no directory by that name in $(/bin/pwd)
		exit 1
	fi
}


if [ $# != 1 ]
then
	echo Usage: print-kernel-version.sh kernel_dir
	exit 1
fi

wantdir $1
cd $1
eval $(head -4 Makefile | sed -e 's/ //g')
echo $VERSION.$PATCHLEVEL.$SUBLEVEL$EXTRAVERSION
