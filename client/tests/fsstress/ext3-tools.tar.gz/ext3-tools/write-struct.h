struct write_struct {
	unsigned long sequence;	/* ino + offset of this struct */
	unsigned long line_count;
	time_t now;
	unsigned long ino;
	unsigned long offset;
	char filename[44];
};

