#!/bin/sh
#
# ts-copy-kenrel
#

#THINGS_TO_KILL cp

cd $1
cp -a /lib ./lib-1 &
cp -a /lib ./lib-2

