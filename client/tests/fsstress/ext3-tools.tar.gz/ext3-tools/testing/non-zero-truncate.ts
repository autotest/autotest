#!/bin/sh
#
# non-zero-truncate.ts
#
# A one-shot which crashes the fs while files are truncate but open
#

#THINGS_TO_KILL sleep

ORPHAN=orphan_file
TRUNCATE_TO=$(/bin/pwd)/../tools/truncate-to

cd $1
for i in 1 2 3 4 5 6 7 8 9
do
	name=$ORPHAN.$i
	INITIAL_LENGTH="$i"0000
	TRUNCATED_LENGTH=$(expr $INITIAL_LENGTH \* 2)
	TRUNCATED_LENGTH=$(expr $TRUNCATED_LENGTH / 3)
	dd if=/dev/zero of=$name count=1 bs=$INITIAL_LENGTH
	( sleep 100 < $name ) &
	$TRUNCATE_TO $name $TRUNCATED_LENGTH
done
sleep 1000
