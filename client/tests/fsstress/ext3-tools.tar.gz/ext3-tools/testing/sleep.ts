#!/bin/sh
#
# ts-sleep: just sleep.  For testing the main script
#

#THINGS_TO_KILL sleep

cd $1
sleep 1000
