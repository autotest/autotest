#include <stdlib.h>
#include <unistd.h>
#include <stdio.h>
#include <fcntl.h>

int main(int argc, char *argv[])
{
	int fd;
	int c;

	if (argc > 1) {
		fd = open(argv[1], O_RDONLY);
		if (fd < 0) {
			perror(argv[1]);
			exit(1);
		}
	} else {
		fd = fileno(stdin);
	}

	while (read(fd, &c, 1) == 1)
		;
	exit(0);
}
