struct st;

static int foo(int a)
{
	return (struct/st *) a;
}
