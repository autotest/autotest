#include <string.h>

static void foo(void *a)
{
	memset(foo, + ', 20);
}
