#if 0
/* these should not warn */
#ifdef (
#endif
#ifndef (
#endif
#endif
