static int foo(int a)
{
	a |=\1;

	return a;
}
