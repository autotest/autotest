/*
 * Yet more examples from comp.std.c.
 *
 * This should result in "a|". We get it right.
 */
#define a a|
#define b(x) x

b(a)
