/* one warning for each, please... */
#define 1
#undef 1
