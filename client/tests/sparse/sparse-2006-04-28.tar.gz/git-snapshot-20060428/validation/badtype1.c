static void foo(enum bar baz);
