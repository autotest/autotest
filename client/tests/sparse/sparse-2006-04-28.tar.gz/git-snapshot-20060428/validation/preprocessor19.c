/* got burned by that - freed the new defintion in the case when we had
   warned and replaced the old one */
#define A x
#define A y
A
