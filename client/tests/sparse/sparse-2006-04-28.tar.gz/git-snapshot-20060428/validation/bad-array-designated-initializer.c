static int a[] = {
	[0] = 0,		// OK
	[\0] = 1,		// KO
};
