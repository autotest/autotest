#define _GNU_SOURCE

#include "lib.h"
#include "allocate.h"

#include "compat/mmap-blob.c"
#include "compat/strtold.c"
