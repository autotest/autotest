#include <stdio.h>

int main()
{
printf("world hello\n");
return 0;
}

