#include "syscalls-ppc.h"

#define KERNEL_ADDR	0xc0000000

