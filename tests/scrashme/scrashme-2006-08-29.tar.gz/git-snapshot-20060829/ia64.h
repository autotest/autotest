#include "syscalls-ia64.h"

#define KERNEL_ADDR	0xa000000100000000
